package com.firstham.aethergui

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.content.BroadcastReceiver
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import android.widget.*
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.Properties
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.net.Socket
import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import java.io.BufferedInputStream

class FoxyMainActivity : Activity() {
    private val bg = Color.rgb(10, 16, 32)
    private val panel = Color.rgb(17, 29, 50)
    private val green = Color.rgb(101, 230, 181)
    private val pale = Color.rgb(235, 243, 255)
    private val muted = Color.rgb(155, 175, 201)
    private val worker = Executors.newSingleThreadExecutor()
    private var session: Session? = null
    private var pantherVpnRequested = false
    private val vpnConsentRequest = 8137
    private val vpnStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AetherVpnService.ACTION_STATUS) {
                val state = intent.getStringExtra("state") ?: "unknown"
                val message = intent.getStringExtra("message") ?: state
                runOnUiThread {
                    status.text = "●  ${state.uppercase()}"
                    status.setTextColor(if (state == "connected") green else muted)
                    appendLog("Panther VPN: $message")
                    if (state == "disconnected" || state == "blocked") { pantherVpnRequested = false; connect.text = "CONNECT"; connect.isEnabled = true }
                }
            }
        }
    }
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var connect: Button
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var serverPicker: Spinner
    private lateinit var modePicker: Spinner
    private lateinit var payloadField: EditText
    private lateinit var sniField: EditText
    private lateinit var proxyHostField: EditText
    private lateinit var proxyPortField: EditText
    private val savedServers = mutableListOf<JSONObject>()
    private var updatingServerPicker = false
    private var ignoreNextServerSelection = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        val filter = IntentFilter(AetherVpnService.ACTION_STATUS)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(vpnStatusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(vpnStatusReceiver, filter)
    }

    override fun onDestroy() {
        try { unregisterReceiver(vpnStatusReceiver) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnConsentRequest) {
            if (resultCode == RESULT_OK) startPantherVpn()
            else appendLog("VPN permission was denied; no tunnel was started.")
        }
    }

    private fun requestPantherVpn() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) startActivityForResult(prepare, vpnConsentRequest) else startPantherVpn()
    }

    private fun startPantherVpn() {
        try {
            val prefs = getSharedPreferences("aether", MODE_PRIVATE)
            prefs.edit().putString("mode", "vpn").putString("engine", "turbo").apply()
            val intent = VpnConnectionController.startIntent(this, prefs)
            ContextCompat.startForegroundService(this, intent)
            pantherVpnRequested = true
            connect.text = "DISCONNECT"
            status.text = "●  STARTING VPN..."; status.setTextColor(green)
            appendLog("Started Panther VpnService. Wait for the service status; actual success depends on the selected engine and network.")
        } catch (e: Exception) { appendLog("Could not start Panther VPN: ${e.message}") }
    }

    private fun disconnectPantherVpn() {
        try { VpnConnectionController.disconnect(this); appendLog("Sent disconnect request to Panther VpnService.") }
        catch (e: Exception) { appendLog("Could not stop Panther VPN: ${e.message}") }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "盾"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(green)
            background = rounded(Color.rgb(24, 59, 69), 18); layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        header.addView(logo)
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), 0, 0, 0) }
        titles.addView(label("Foxy VPN", 25f, pale, true))
        titles.addView(label("SSH TUNNEL  •  ANDROID", 11f, muted, false))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        root.addView(space(24))

        val hero = card()
        hero.gravity = Gravity.CENTER
        hero.setPadding(dp(18), dp(25), dp(18), dp(25))
        status = label("●  DISCONNECTED", 13f, muted, true).apply { gravity = Gravity.CENTER }
        hero.addView(status)
        val power = TextView(this).apply {
            text = "⏻"; textSize = 58f; gravity = Gravity.CENTER; setTextColor(green)
            background = rounded(Color.rgb(24, 59, 69), 100)
            layoutParams = LinearLayout.LayoutParams(dp(142), dp(142)).apply { topMargin = dp(20); bottomMargin = dp(18) }
        }
        hero.addView(power)
        hero.addView(label("Secure SSH Connection", 19f, pale, true).apply { gravity = Gravity.CENTER })
        hero.addView(label("Connect to your SSH server", 13f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) })
        root.addView(hero)
        root.addView(space(16))

        root.addView(label("GET STARTED", 12f, green, true))
        root.addView(space(10))
        val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val serverChoice = Button(this).apply {
            text = "Choose Server"; isAllCaps = false; textSize = 13f; setTextColor(bg)
            background = rounded(green, 14)
            setOnClickListener { scroll.post { scroll.smoothScrollTo(0, fieldsTop()) } }
        }
        val firefoxChoice = Button(this).apply {
            text = "Login Firefox"; isAllCaps = false; textSize = 13f; setTextColor(pale)
            background = rounded(Color.rgb(39, 57, 82), 14)
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.firefox.com/signin")))
                    appendLog("Opened Firefox Account sign-in in your browser. This is browser sign-in only; app account linking is not implemented.")
                } catch (e: Exception) { appendLog("Could not open Firefox sign-in: ${e.message}") }
            }
        }
        choices.addView(serverChoice, LinearLayout.LayoutParams(0, dp(50), 1f).apply { rightMargin = dp(6) })
        choices.addView(firefoxChoice, LinearLayout.LayoutParams(0, dp(50), 1f).apply { leftMargin = dp(6) })
        root.addView(choices)
        root.addView(space(20))

        root.addView(label("SERVER CONFIGURATION", 12f, green, true))
        root.addView(space(10))
        val serverPanel = card()
        serverPanel.addView(label("Connection source", 13f, muted, true))
        serverPicker = Spinner(this)
        serverPicker.background = rounded(Color.rgb(9, 17, 31), 12)
        serverPanel.addView(serverPicker, matchTop())
        val serverActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val saveServer = Button(this).apply {
            text = "SAVE MY SERVER"; isAllCaps = false; textSize = 12f; setTextColor(bg); background = rounded(green, 12)
            setOnClickListener { saveCurrentServer() }
        }
        val removeServer = Button(this).apply {
            text = "REMOVE SAVED"; isAllCaps = false; textSize = 12f; setTextColor(pale); background = rounded(Color.rgb(39, 57, 82), 12)
            setOnClickListener { removeSelectedServer() }
        }
        serverActions.addView(saveServer, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(5) })
        serverActions.addView(removeServer, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(5) })
        serverPanel.addView(space(8)); serverPanel.addView(serverActions)
        root.addView(serverPanel)
        root.addView(space(10))
        val fields = card()
        fields.addView(label("SSH Host / IP", 13f, muted, true))
        host = edit("example.com", false); fields.addView(host, matchTop())
        fields.addView(label("Port", 13f, muted, true).apply { setPadding(0, dp(12), 0, 0) })
        port = edit("22", false); fields.addView(port, matchTop())
        fields.addView(label("Username", 13f, muted, true).apply { setPadding(0, dp(12), 0, 0) })
        username = edit("SSH username", false); fields.addView(username, matchTop())
        fields.addView(label("Password", 13f, muted, true).apply { setPadding(0, dp(12), 0, 0) })
        password = edit("SSH password", true); fields.addView(password, matchTop())
        root.addView(fields)
        root.addView(space(12))

        val modePanel = card()
        modePanel.addView(label("CONNECTION MODE", 12f, green, true))
        modePanel.addView(space(6))
        modePanel.addView(label("Select a mode and configure its values", 13f, muted, false))
        modePicker = Spinner(this).apply { background = rounded(Color.rgb(9, 17, 31), 12) }
        val modeNames = listOf("Direct SSH", "HTTP Payload", "SSL/TLS + SNI", "Payload + SNI", "HTTP Proxy", "Payload + HTTP Proxy", "Panther VPN (Full Device)")
        modePicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modeNames)
        modePanel.addView(modePicker, matchTop())

        fun addModeField(caption: String, hintText: String, key: String, secret: Boolean = false): EditText {
            modePanel.addView(label(caption, 13f, muted, true).apply { setPadding(0, dp(10), 0, 0) })
            val field = edit(hintText, secret)
            field.setText(getSharedPreferences("foxy_mode", MODE_PRIVATE).getString(key, "") ?: "")
            field.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    getSharedPreferences("foxy_mode", MODE_PRIVATE).edit().putString(key, s?.toString() ?: "").apply()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
            modePanel.addView(field, matchTop())
            return field
        }
        payloadField = addModeField("HTTP Payload", "e.g. CONNECT [host_port] [protocol][crlf][crlf]", "payload")
        sniField = addModeField("SNI / TLS Host", "e.g. tls.example.com", "sni")
        proxyHostField = addModeField("HTTP Proxy Host (optional)", "proxy.example.com", "proxy_host")
        proxyPortField = addModeField("HTTP Proxy Port", "8080", "proxy_port")
        modePicker.setSelection(getSharedPreferences("foxy_mode", MODE_PRIVATE).getInt("mode", 0).coerceIn(0, modeNames.lastIndex))
        modePicker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                getSharedPreferences("foxy_mode", MODE_PRIVATE).edit().putInt("mode", position).apply()
                if (::log.isInitialized) appendLog("Selected connection mode: ${modeNames[position]}")
            }
        }
        val saveMode = Button(this).apply {
            text = "SAVE CONNECTION SETTINGS"; isAllCaps = false; textSize = 12f; setTextColor(bg); background = rounded(green, 12)
            setOnClickListener {
                getSharedPreferences("foxy_mode", MODE_PRIVATE).edit().putInt("mode", modePicker.selectedItemPosition)
                    .putString("payload", payloadField.text.toString()).putString("sni", sniField.text.toString())
                    .putString("proxy_host", proxyHostField.text.toString()).putString("proxy_port", proxyPortField.text.toString()).apply()
                appendLog("Connection mode and custom values saved on this device.")
            }
        }
        modePanel.addView(space(10)); modePanel.addView(saveMode, matchTop())
        root.addView(modePanel)
        root.addView(space(16))
        loadSavedServers()
        refreshServerPicker()

        val warning = TextView(this).apply {
            text = "ⓘ  SERVER PROFILE and CONNECTION MODE are separate. Direct SSH authenticates an SSH session; HTTP Payload, TLS/SNI and HTTP Proxy currently run transport/protocol checks only and do NOT create a full-device VPN tunnel. Panther VPN starts the integrated VpnService engine; it does not automatically turn an SSH session into a tunnel."
            textSize = 12f; setTextColor(muted); setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(Color.rgb(23, 35, 56), 14)
        }
        root.addView(warning)
        root.addView(space(16))
        connect = Button(this).apply {
            text = "CONNECT"; textSize = 15f; isAllCaps = false; setTextColor(bg)
            background = rounded(green, 16); setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener {
                if (modePicker.selectedItemPosition == 6) { if (pantherVpnRequested) disconnectPantherVpn() else requestPantherVpn() }
                else if (session?.isConnected == true) disconnect()
                else if (modePicker.selectedItemPosition == 0) connectSsh()
                else connectTransportMode()
            }
        }
        root.addView(connect, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(space(22))
        root.addView(label("CONNECTION LOG", 12f, green, true))
        root.addView(space(8))
        log = TextView(this).apply {
            text = "Ready. Enter your SSH server details.\n"; textSize = 12f; setTextColor(muted); typeface = Typeface.MONOSPACE
            setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(Color.rgb(7, 12, 24), 14)
        }
        root.addView(log)
    }

    private fun loadSavedServers() {
        savedServers.clear()
        try {
            val raw = getSharedPreferences("foxy_servers", MODE_PRIVATE).getString("items", "[]") ?: "[]"
            val array = JSONArray(raw)
            for (i in 0 until array.length()) savedServers.add(array.getJSONObject(i))
        } catch (_: Exception) { savedServers.clear() }
    }

    private fun persistSavedServers() {
        val array = JSONArray()
        savedServers.forEach { array.put(it) }
        getSharedPreferences("foxy_servers", MODE_PRIVATE).edit().putString("items", array.toString()).apply()
    }

    private fun refreshServerPicker(selectIndex: Int = 0) {
        updatingServerPicker = true
        ignoreNextServerSelection = true
        val options = mutableListOf("FoxyVPN servers (server list not configured)")
        savedServers.forEach { options.add(it.optString("name", it.optString("host", "My server"))) }
        serverPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        serverPicker.setSelection(selectIndex.coerceIn(0, options.lastIndex))
        serverPicker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (updatingServerPicker) { updatingServerPicker = false; return }
                if (ignoreNextServerSelection) { ignoreNextServerSelection = false; return }
                if (position == 0) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("FoxyVPN server list")
                        .setMessage("This project does not include an official FoxyVPN server directory or API credentials, so no real FoxyVPN servers can be listed yet. Choose a saved server or add your own SSH server below.")
                        .setPositiveButton("OK", null).show()
                } else {
                    val item = savedServers[position - 1]
                    host.setText(item.optString("host")); port.setText(item.optString("port", "22"))
                    username.setText(item.optString("username")); password.setText("")
                    appendLog("Selected saved server: ${item.optString("name")}")
                }
            }
        }
        updatingServerPicker = false
    }

    private fun saveCurrentServer() {
        val h = host.text.toString().trim()
        val p = port.text.toString().toIntOrNull()
        val u = username.text.toString().trim()
        val pw = password.text.toString()
        if (h.isBlank() || p == null || p !in 1..65535 || u.isBlank()) {
            appendLog("Enter a valid host, port and username before saving the profile."); return
        }
        val nameInput = EditText(this).apply { hint = "Server name (e.g. My SSH)"; setText(h) }
        AlertDialog.Builder(this).setTitle("Save custom server")
            .setView(nameInput)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim().ifBlank { h }
                savedServers.removeAll { it.optString("name") == name }
                savedServers.add(JSONObject().put("name", name).put("host", h).put("port", p.toString()).put("username", u))
                persistSavedServers(); refreshServerPicker(savedServers.size)
                password.setText("")
                appendLog("Saved custom server profile: $name. Password is not stored; enter it when connecting.")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun removeSelectedServer() {
        val index = serverPicker.selectedItemPosition
        if (index <= 0 || index - 1 !in savedServers.indices) {
            appendLog("Select one of your saved servers to remove."); return
        }
        val name = savedServers[index - 1].optString("name")
        savedServers.removeAt(index - 1); persistSavedServers(); refreshServerPicker()
        appendLog("Removed saved server: $name")
    }


    private fun connectTransportMode() {
        val mode = modePicker.selectedItemPosition
        val targetHost = host.text.toString().trim()
        val targetPort = port.text.toString().toIntOrNull()
        val proxyHost = proxyHostField.text.toString().trim().ifBlank { targetHost }
        val proxyPort = proxyPortField.text.toString().toIntOrNull() ?: if (mode == 2 || mode == 3) 443 else targetPort
        val sni = sniField.text.toString().trim()
        val payload = payloadField.text.toString()
        if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) { appendLog("Enter a valid target host and port."); return }
        if ((mode == 4 || mode == 5) && (proxyHost.isBlank() || proxyPort == null || proxyPort !in 1..65535)) { appendLog("Enter a valid HTTP proxy host and port."); return }
        if ((mode == 2 || mode == 3) && sni.isBlank()) { appendLog("Enter an SNI/TLS hostname."); return }
        hideKeyboard(); connect.isEnabled = false; status.text = "●  CONNECTING..."; status.setTextColor(green)
        appendLog("Starting ${modePicker.selectedItem} transport check. This check is not a full-device VPN connection.")
        worker.execute {
            var sock: Socket? = null
            try {
                when (mode) {
                    1 -> {
                        sock = Socket(); sock.connect(InetSocketAddress(targetHost, targetPort), 12000); sock.soTimeout = 8000
                        val wire = normalizePayload(payload.ifBlank { "GET / HTTP/1.1[crlf]Host: $targetHost[crlf]Connection: close[crlf][crlf]" }, targetHost, targetPort)
                        sock.getOutputStream().write(wire.toByteArray(Charsets.ISO_8859_1)); sock.getOutputStream().flush()
                        val response = readResponse(sock)
                        runOnUiThread { appendLog("Payload response preview:\n$response") }
                    }
                    2, 3 -> {
                        val tlsPort = if (targetPort == 22) 443 else targetPort
                        val raw = Socket(); raw.connect(InetSocketAddress(targetHost, tlsPort), 12000)
                        val tls = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, sni, tlsPort, true) as SSLSocket
                        tls.soTimeout = 8000
                        tls.sslParameters = tls.sslParameters.apply { serverNames = listOf(javax.net.ssl.SNIHostName(sni)) }
                        tls.startHandshake(); sock = tls
                        if (mode == 3 && payload.isNotBlank()) { tls.getOutputStream().write(normalizePayload(payload, targetHost, tlsPort).toByteArray(Charsets.ISO_8859_1)); tls.getOutputStream().flush() }
                        runOnUiThread { appendLog("TLS handshake succeeded for SNI $sni. ${if (mode == 3) "Custom payload sent if supplied." else "Handshake only."} Not a VPN tunnel.") }
                    }
                    4, 5 -> {
                        sock = Socket(); sock.connect(InetSocketAddress(proxyHost, proxyPort!!), 12000); sock.soTimeout = 8000
                        val req = if (mode == 5 && payload.isNotBlank()) normalizePayload(payload, targetHost, targetPort) else "CONNECT $targetHost:$targetPort HTTP/1.1\r\nHost: $targetHost:$targetPort\r\nProxy-Connection: Keep-Alive\r\n\r\n"
                        sock.getOutputStream().write(req.toByteArray(Charsets.ISO_8859_1)); sock.getOutputStream().flush()
                        val response = readResponse(sock); val ok = response.startsWith("HTTP/1.1 200") || response.startsWith("HTTP/1.0 200")
                        runOnUiThread { appendLog("Proxy response:\n$response"); appendLog(if (ok) "Proxy CONNECT accepted; device traffic is not routed yet." else "Proxy did not return HTTP 200.") }
                        if (!ok) throw IllegalStateException("HTTP proxy CONNECT was not accepted")
                    }
                }
                runOnUiThread { status.text = "●  CHECK COMPLETE (NOT VPN)"; status.setTextColor(green); connect.text = "TEST MODE"; connect.isEnabled = true }
            } catch (e: Exception) {
                try { sock?.close() } catch (_: Exception) {}
                runOnUiThread { status.text = "●  CONNECTION FAILED"; status.setTextColor(Color.rgb(255,130,130)); connect.isEnabled = true; appendLog("Connection test failed: ${e.message ?: e.javaClass.simpleName}") }
            } finally { try { sock?.close() } catch (_: Exception) {} }
        }
    }

    private fun normalizePayload(input: String, targetHost: String, targetPort: Int): String = input
        .replace("[host_port]", "$targetHost:$targetPort", ignoreCase = true)
        .replace("[host]", targetHost, ignoreCase = true)
        .replace("[port]", targetPort.toString(), ignoreCase = true)
        .replace("[protocol]", "HTTP/1.1", ignoreCase = true)
        .replace("[crlf]", "\r\n", ignoreCase = true)
        .replace("[lf]", "\n", ignoreCase = true)

    private fun readResponse(socket: Socket, maxBytes: Int = 4096): String {
        val input = BufferedInputStream(socket.getInputStream()); val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(512)
        while (out.size() < maxBytes) {
            val n = input.read(buffer, 0, minOf(buffer.size, maxBytes - out.size())); if (n <= 0) break
            out.write(buffer, 0, n); val str = out.toString("ISO-8859-1")
            if (str.contains("\r\n\r\n") || str.contains("\n\n")) break
        }
        return out.toString("ISO-8859-1").ifBlank { "(No response received)" }
    }

    private fun connectSsh() {
        val h = host.text.toString().trim()
        val p = port.text.toString().toIntOrNull()
        val u = username.text.toString().trim()
        val pw = password.text.toString()
        if (h.isBlank() || p == null || p !in 1..65535 || u.isBlank() || pw.isEmpty()) {
            appendLog("Please fill in host, valid port, username and password."); return
        }
        hideKeyboard()
        connect.isEnabled = false
        status.text = "●  CONNECTING..."; status.setTextColor(green)
        appendLog("Connecting to $h:$p ...")
        worker.execute {
            var candidate: Session? = null
            try {
                val jsch = JSch()
                candidate = jsch.getSession(u, h, p)
                candidate.setPassword(pw)
                candidate.userInfo = object : UserInfo {
                    override fun getPassphrase(): String? = null
                    override fun getPassword(): String = pw
                    override fun promptPassword(message: String?): Boolean = true
                    override fun promptPassphrase(message: String?): Boolean = false
                    override fun promptYesNo(message: String?): Boolean {
                        val answer = booleanArrayOf(false)
                        val latch = CountDownLatch(1)
                        runOnUiThread {
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("Trust SSH host key?")
                                .setMessage((message ?: "Unknown host key") + "\n\nOnly accept if you trust this server and have verified its fingerprint.")
                                .setPositiveButton("Trust for this session") { _, _ -> answer[0] = true; latch.countDown() }
                                .setNegativeButton("Cancel") { _, _ -> answer[0] = false; latch.countDown() }
                                .setOnCancelListener { answer[0] = false; latch.countDown() }
                                .show()
                        }
                        return latch.await(90, TimeUnit.SECONDS) && answer[0]
                    }
                    override fun showMessage(message: String?) { runOnUiThread { appendLog(message ?: "SSH server message") } }
                }
                val config = Properties()
                config["StrictHostKeyChecking"] = "ask"
                config["PreferredAuthentications"] = "password,keyboard-interactive"
                candidate.setConfig(config)
                candidate.connect(15000)
                session = candidate
                runOnUiThread {
                    status.text = "●  SSH CONNECTED"; status.setTextColor(green)
                    connect.text = "DISCONNECT"; connect.isEnabled = true
                    appendLog("SSH authentication succeeded.")
                    appendLog("Note: internet traffic is not routed through this session yet.")
                }
            } catch (e: Exception) {
                try { candidate?.disconnect() } catch (_: Exception) {}
                runOnUiThread {
                    status.text = "●  CONNECTION FAILED"; status.setTextColor(Color.rgb(255, 130, 130))
                    connect.isEnabled = true
                    appendLog("Error: ${e.message ?: e.javaClass.simpleName}")
                    appendLog("Check server details, network, credentials and host-key trust.")
                }
            }
        }
    }

    private fun disconnect() {
        worker.execute {
            try { session?.disconnect() } catch (_: Exception) {}
            session = null
            runOnUiThread {
                status.text = "●  DISCONNECTED"; status.setTextColor(muted)
                connect.text = "CONNECT"; connect.isEnabled = true
                appendLog("SSH session disconnected.")
            }
        }
    }

    private fun fieldsTop(): Int {
        val fields = host.parent as? View ?: return 0
        var y = fields.top
        var parent = fields.parent
        while (parent is View && parent !== (host.rootView)) {
            y += parent.top
            parent = parent.parent
        }
        return y.coerceAtLeast(0)
    }

    private fun appendLog(message: String) {
        log.append("\n> $message")
    }
    private fun edit(hintText: String, secret: Boolean): EditText = EditText(this).apply {
        hint = hintText; setHintTextColor(Color.rgb(105, 125, 151)); setTextColor(pale); textSize = 15f
        setSingleLine(true); background = rounded(Color.rgb(9, 17, 31), 12)
        setPadding(dp(13), dp(10), dp(13), dp(10))
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        else if (hintText == "22") inputType = android.text.InputType.TYPE_CLASS_NUMBER
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(panel, 18)
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchTop() = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hideKeyboard() { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(currentFocus?.windowToken, 0) }
    override fun onDestroy() { try { session?.disconnect() } catch (_: Exception) {}; worker.shutdownNow(); super.onDestroy() }
}
