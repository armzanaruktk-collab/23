# Third-party notices

Panther is an independent Android client.

## Fork notice

Panther is a fork of https://github.com/hamvex/AetherGUI (released as "Aethon"),
which is itself an independent client for the CluvexStudio/Aether networking core.

Panther is not affiliated with, endorsed by, or supported by the Aethon or Aether
projects. Do not report Panther issues to them.

Distributed under the same AGPL-3.0 license as the upstream project.
Complete corresponding source: https://github.com/Amirmahdavi2022/Panther-VPN

## Aether

This application bundles the Aether core from https://github.com/CluvexStudio/Aether,
licensed under GNU AGPL v3.0.

The Android cores for ARMv7, ARM64 and x86_64 are downloaded from the official
**v2.1.0** release during the build and verified against the publisher-provided
SHA-256 files. The pinned version lives in `scripts/fetch-android-assets.sh`, and
the release workflow fails the build if that pin and the version named here ever
disagree.

Aether and its marks are subject to the upstream project's TRADEMARK.md policy.
Panther is an independent frontend and is not endorsed by CluvexStudio.

## Global engine

The Global engine is the Psiphon tunnel library from
https://github.com/Psiphon-Labs/psiphon-tunnel-core, licensed under GNU GPL v3.0,
which is compatible with the AGPL-3.0 this project is under.

It ships as the official prebuilt `ca.psiphon.aar` from release **v2.0.40**. That
asset is not signed by the publisher, so the build pins it by SHA-256 in
`scripts/fetch-android-assets.sh` and refuses to build if the hash does not match.

Psiphon and its marks belong to Psiphon Inc. Panther is an independent client and
is not affiliated with, endorsed by or supported by them. Do not report Panther
issues to Psiphon.

## Stealth engine

The Stealth engine is the Xray core from https://github.com/XTLS/Xray-core,
licensed under the Mozilla Public License 2.0, which is compatible with the
AGPL-3.0 this project is under.

It is built from source at tag **v26.3.27**, commit
`d2758a023cd7f4174a5a5fa4ff66e487d4342ba0`, which `scripts/fetch-android-assets.sh`
verifies after cloning and refuses to build past if it does not match. The source
is used unmodified; only the build flags are ours. It ships as a standalone
executable, not as a library, and Panther adds no code to it.

Xray, XTLS and their marks belong to their respective authors. Panther is an
independent client and is not affiliated with, endorsed by or supported by them.
Do not report Panther issues to that project.

## HEV Socks5 Tunnel

Android VPN routing uses HEV Socks5 Tunnel v2.16.0 from
https://github.com/heiher/hev-socks5-tunnel under the MIT license. The full text is
in `third-party/hev-socks5-tunnel-LICENSE.txt`.

## Zeptun (fast TUN bridge)

The optional "Fast Tunnel" bridge is Zeptun from https://github.com/Noisemux/zeptun,
licensed under the MIT License, Copyright (c) 2026 Noisemux. The full text is in
`third-party/zeptun-LICENSE.txt`.

Panther ships `libzeptun-jni.so` from the official **v1.0.0** release
(`zeptun-android-jniLibs.zip`), which `scripts/fetch-android-assets.sh` pins by SHA-256 and
refuses to build past if the hash does not match. It is used unmodified.

## ics-openvpn

The relay engine in `android/vpnLib` is derived from ics-openvpn by Arne Schwabe,
licensed under GNU GPL v2.0. It ships in the package but is not reachable from the
UI in this release.

## Location lookup

The location card asks one of four public services which address the tunnel comes
out of: `speed.cloudflare.com`, `www.cloudflare.com/cdn-cgi/trace`, `ipwho.is` and
`ipapi.co`. Every request goes through the tunnel's own SOCKS proxy, so none of them
ever sees the device's real address. No account or API key is used and nothing is
stored.

## Beacon engine

The Beacon engine is the flashlight library from
https://github.com/getlantern/flashlight, published by Brave New Software under the
GNU General Public License v3.0, which is compatible with the AGPL-3.0 this project
is under.

It is pinned at **v7.6.241** and built from source by
`scripts/fetch-android-assets.sh`, which writes a small `main()` around the library
and compiles it as a standalone executable. No upstream source file is committed to
this repository. The library itself is used unmodified; only the entry point and the
build flags are ours.

Lantern, flashlight and their marks belong to Brave New Software. Panther is an
independent client and is not affiliated with, endorsed by or supported by them. Do
not report Panther issues to that project.

## byedpi

The local shaping proxy used by the Prowl engine's spoof route. Fetched at build time from
https://github.com/hufrea/byedpi, pinned to tag **v0.17.3** (commit
`7efde1b1296eaaa187b70e951894dde17527489c`) and compiled from source by
`scripts/fetch-android-assets.sh`. No byedpi binary or source file is committed to this repository.

byedpi is licensed under the MIT License, Copyright (c) hufrea.

The build applies `-D_DEFAULT_SOURCE`, matching byedpi's own Makefile, and omits `win_service.c`,
which is the Windows service entry point.

